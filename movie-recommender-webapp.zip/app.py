"""
Movie Taste Cluster Finder — Streamlit Web App
------------------------------------------------
A dashboard UI for the K-Means movie recommendation model.

Unlike a "predict" model, K-Means is unsupervised — there's no single
right answer. This app lets you set your own genre preferences, then
shows which taste cluster you'd land in, how that cluster compares to
the others, and who else shares your taste.

BEFORE YOU RUN THIS:
  1. Install dependencies:
       pip install streamlit pandas scikit-learn matplotlib
  2. Make sure "movies.csv" is in this same folder.
  3. Run with:
       streamlit run app.py
"""

import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt
import matplotlib
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

matplotlib.rcParams['font.family'] = 'DejaVu Sans'

GENRES = ["Action", "Comedy", "Drama", "Horror", "Romance", "SciFi"]

# ---------------------------------------------------------------------------
# Page config + styling — Cinema Red & Charcoal theme
# ---------------------------------------------------------------------------

st.set_page_config(page_title="Movie Taste Cluster Finder", page_icon="🎬", layout="wide")

st.markdown("""
<style>
    .stApp { background-color: #17181C; }
    section[data-testid="stSidebar"] { background-color: #202126; }
    div[data-testid="stMetric"] {
        background-color: #202126;
        border: 1px solid #34363E;
        border-radius: 10px;
        padding: 16px;
    }
    div.stButton > button {
        background-color: #E5304C;
        color: #17181C;
        font-weight: 600;
        border: none;
    }
    div.stButton > button:hover {
        background-color: #F05770;
        color: #17181C;
    }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Fit K-Means once per session
# ---------------------------------------------------------------------------

@st.cache_resource
def load_model():
    df = pd.read_csv("movies.csv")
    X = df[GENRES]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
    df["Cluster"] = kmeans.fit_predict(X_scaled)

    cluster_means = df.groupby("Cluster")[GENRES].mean()

    return df, scaler, kmeans, cluster_means


df, scaler, kmeans, cluster_means = load_model()


def name_cluster(profile):
    """Give each cluster a human-readable label based on its top genres."""
    top2 = profile.sort_values(ascending=False).index[:2].tolist()
    return " / ".join(top2) + " Fans"


cluster_labels = {c: name_cluster(cluster_means.loc[c]) for c in cluster_means.index}


# ---------------------------------------------------------------------------
# Sidebar — Model Control
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown("## 🎬 Model Control")
    st.markdown("### Model Info")
    st.markdown("🔹 **Algorithm:** K-Means Clustering")
    st.markdown(f"🔹 **Dataset:** {len(df)} users")
    st.markdown("🔹 **Clusters:** 3 taste groups")
    st.markdown("---")
    st.markdown("### Note")
    st.caption("K-Means is unsupervised — there's no 'correct' cluster, just groups the model found in the data.")


# ---------------------------------------------------------------------------
# Main panel
# ---------------------------------------------------------------------------

st.title("Movie Taste Cluster Finder")
st.caption("Rate each genre 1-5, and find out which taste cluster you belong to.")

st.markdown("---")

col1, col2 = st.columns([1, 1.3])

with col1:
    st.markdown("### Your Genre Ratings")
    user_ratings = {}
    defaults = {"Action": 5, "Comedy": 2, "Drama": 1, "Horror": 1, "Romance": 2, "SciFi": 5}
    for genre in GENRES:
        user_ratings[genre] = st.slider(genre, 1, 5, defaults[genre])

    find_clicked = st.button("🎬 Find My Cluster", type="primary")

with col2:
    if find_clicked:
        user_vec = np.array([[user_ratings[g] for g in GENRES]])
        user_scaled = scaler.transform(user_vec)
        cluster = kmeans.predict(user_scaled)[0]
        label = cluster_labels[cluster]

        st.markdown(f"### You're in: **{label}**")

        # Bar chart: user profile vs cluster average
        fig, ax = plt.subplots(figsize=(7, 4.6), dpi=150)
        fig.patch.set_facecolor('#17181C')
        ax.set_facecolor('#17181C')

        x = np.arange(len(GENRES))
        width = 0.35
        user_vals = [user_ratings[g] for g in GENRES]
        cluster_vals = cluster_means.loc[cluster].values

        ax.bar(x - width/2, user_vals, width, color="#E5304C", label="You")
        ax.bar(x + width/2, cluster_vals, width, color="#4A90D9", label="Cluster Avg")

        ax.set_xticks(x)
        ax.set_xticklabels(GENRES, color="#D8DAE0", fontsize=10)
        ax.set_ylabel("Rating", color="#D8DAE0")
        ax.tick_params(colors="#8B8E99")
        for spine in ax.spines.values():
            spine.set_color("#34363E")
        ax.legend(frameon=False, labelcolor="#D8DAE0", fontsize=9)
        ax.grid(True, axis='y', linestyle='--', linewidth=0.5, color="#34363E", alpha=0.6)

        st.pyplot(fig)

        # Similar users from the same cluster
        similar = df[df["Cluster"] == cluster].head(5)
        st.markdown("#### 👥 A Few Users Like You")
        st.dataframe(similar[["UserID"] + GENRES], hide_index=True, use_container_width=True)
    else:
        st.info("Set your ratings and click **Find My Cluster** to see your taste group.")
